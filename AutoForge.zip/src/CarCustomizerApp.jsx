import React, { useRef, useState, useEffect } from "react";
import { fabric } from "fabric";

export default function CarCustomizerApp() {
  const [canvasType, setCanvasType] = useState("exterior");
  const canvasRef = useRef(null);

  const initCanvas = () => {
    canvasRef.current = new fabric.Canvas("car-canvas", {
      height: 500,
      width: 800,
      backgroundColor: "#f3f4f6",
    });

    fabric.Image.fromURL("/force-gurkha-5door.png", (img) => {
      img.scaleToWidth(600);
      canvasRef.current.setBackgroundImage(
        img,
        canvasRef.current.renderAll.bind(canvasRef.current)
      );
    });
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      fabric.Image.fromURL(reader.result, (img) => {
        img.scaleToWidth(600);
        canvasRef.current.clear();
        canvasRef.current.setBackgroundImage(
          img,
          canvasRef.current.renderAll.bind(canvasRef.current)
        );
      });
    };
    reader.readAsDataURL(file);
  };

  const addAccessory = (url) => {
    fabric.Image.fromURL(url, (img) => {
      img.scale(0.3);
      img.set({ left: 100, top: 100 });
      canvasRef.current.add(img);
    });
  };

  const changeCarColor = (color) => {
    const bg = canvasRef.current.backgroundImage;
    if (bg) {
      const filter = new fabric.Image.filters.Tint({ color, opacity: 0.5 });
      bg.filters = [filter];
      bg.applyFilters();
      canvasRef.current.renderAll();
    }
  };

  const downloadImage = () => {
    const dataURL = canvasRef.current.toDataURL({ format: "png" });
    const a = document.createElement("a");
    a.href = dataURL;
    a.download = `${canvasType}-custom-car.png`;
    a.click();
  };

  useEffect(() => {
    initCanvas();
  }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Car Customizer - {canvasType}</h1>

      <div className="flex gap-4">
        <button className="px-4 py-2 bg-blue-500 text-white rounded" onClick={() => setCanvasType("exterior")}>Exterior</button>
        <button className="px-4 py-2 bg-green-500 text-white rounded" onClick={() => setCanvasType("interior")}>Interior</button>
        <input type="file" accept="image/*" onChange={handleImageUpload} />
        <button className="px-4 py-2 bg-red-500 text-white rounded" onClick={downloadImage}>Download</button>
      </div>

      <div className="flex gap-2">
        <button onClick={() => changeCarColor("red")} className="px-2 py-1 bg-red-400 rounded">Red</button>
        <button onClick={() => changeCarColor("blue")} className="px-2 py-1 bg-blue-400 rounded">Blue</button>
        <button onClick={() => changeCarColor("black")} className="px-2 py-1 bg-gray-800 text-white rounded">Black</button>
      </div>

      <div className="flex gap-2">
        <button onClick={() => addAccessory("/spoiler.png")} className="px-2 py-1 bg-yellow-300 rounded">Add Spoiler</button>
        <button onClick={() => addAccessory("/steering.png")} className="px-2 py-1 bg-pink-300 rounded">Add Steering</button>
      </div>

      <canvas id="car-canvas" className="border rounded shadow" />
    </div>
  );
}